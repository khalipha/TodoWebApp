<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Approve Account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-grid.min.css"/>

  <script src="jquery.js"></script>
   <script src="bootstrap/js/bootstrap.min.js"></script>

   <style>
body 
{
  font-family: "Lato", sans-serif;
}

.sidenav 
{
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a 
{
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover 
{
  color: #f1f1f1;
}

.sidenav .closebtn 
{
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) 
{
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="Forms.html">Release Track/Album</a>
  <a href="Approve_Release.php">Approve Release</a>
  <a href="Approve_Account.php">Approve Account</a>
  <a href="Sales.php">Update Sales</a> 
  <a href="PostBlog.php">Post Blog</a>
  <a href="../index.html">Logout</a>
</div>

<h2>Andministrator Panel</h2>
<p>QPhonic Entertainment</p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<?php

?>


<center>

<br/><h2>Approve Account</h2><br/>

    
		  <!-- <input type="button" class="btn btn-success" value="Approve" name="Approve_Account"/>
		  <input type="button" class="btn btn-danger" value="Disapprove" name="Disapprove_Account"/>
       -->
      
	
	  
</center>


<?php
   include 'db.php';


      $sql = "select * from record_signup";
      $result = $conn->query($sql);
      while($row = $result->fetch_assoc())
           {
        echo "<p>".  $row['Record_Signup']  ."</p>";
        echo "<p><b>Record Label:</b> ".  $row['Record_label_Name']  ."</p>";
        echo "<p><b>Country:</b> ".  $row['Record_Country']  ."</p>";
        echo "<p><b>Record Full Name:</b> " . $row['Record_Full_Name']  . "</p>";
        echo "<p><b>Record Email Address:</b> " . $row['Record_Email']  . "</p>";
        echo "<p><b>Record Label Phone Number:</b> " . $row['Record_Phone']  . "</p>";
        echo "<p><b>Record Label Physical Address:</b> " . $row['Record_Physical_Address']  . "</p>";
       
        echo "<p><b>Artist Account No. :</b> " . $row['Artist_Account_Number'] . "</p>";
        echo "<p><b>Artist Email Address :</b> " . $row['Artist_Email']  . "</p>";
        echo "<p><b>Artist Full Name(s) :</b> " . $row['Artist_First_Name']  . "</p>";
        echo "<p><b>Artist Phone No. :</b> " . $row['Artist_Phone']  . "</p>";
        //echo "<p><b>Status :</b> " . $row['Status']  . "</p>";
        // echo "<p>" . $row['Account_Login_UserName']  . "</p>";
        // echo "<p>" . $row['Account_Login_Password']  . "</p>";
        $stat = $row['Status'];
        $_SESSION['key'] = $row['Record_Signup'];
           if ($stat==0)
               {
                echo "Status: Account Not Approved yet<br/>";
                echo "<form method='post' action='".ApproveAccount($conn)."'>
                      <button class='btn btn-success' name='Approve_Account'/>Approve</button>
                      </form>";
               }
               else
                 {
                  echo "Satus: Account Approved<br/>";
                  echo "<form method='post' action='".DisapproveAccount($conn)."'>
                        <button class='btn btn-danger' name='Disapprove_Account'>Disapprove</button>
                        </form>";
                 }
           }     
           
           
     function ApproveAccount($conn)
           {
             if(isset($_POST['Approve_Account']))
               {
              $sql = "update record_signup set status=1 where Record_Signup=1";
              $result = $conn->query($sql);
             
               }         
           } 
      function DisapproveAccount($conn)
           {
            if(isset($_POST['Disapprove_Account']))
              {
            $sql = "update record_signup set status=0 where Record_Signup=1";
            $result = $conn->query($sql);
            
             }
          }
?>
