<?php

$index=0;

function Swe($index)
{
    $Enum=1;
    return $index =  $Enum;
}


echo Swe($index);

?> 