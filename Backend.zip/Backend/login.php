<?php
include 'db.php';
ob_start();
?>
<?php
   session_start();
?>
<!DOCTYPE html>
<html>
<body>
	<div class="container">

   </br></br></br></br></br></br></br></br>
   <center><h1>Login</h1>


        <!--start user session details-->
        <div class="row col-md-12 boxUserSession">
          <?php
           if(isset($_SESSION['U_ID']))
           { echo "<h3> <span><img src='../User.png' width='30px' height='30px'> </span>Welcome,</h3>";
             echo "<h3>" .$_SESSION['Name']. "</h3>";}
         else
           { echo "<h3>NOT LOGGED IN</h3>"; }
          ?>
        </div>
        <!--end user session details-->
      <div class="row">
      <div class="col-md-4">
      <div class="boxLogDetails" id="log">

      <!-- Begin user details -->
      <?php
               include 'userdetails.php';
      ?>
      <!-- End user details -->
          
  </div>
  </div>
  </div>
  </center>
</body>
</html>
