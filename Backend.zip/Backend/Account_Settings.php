<?php
include 'db.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Account Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-reboot.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-grid.min.css'/>
<style>
                                    /* Style the tab */
                                    .tab {
                                    overflow: hidden;
                                    border: 1px solid #ccc;
                                    background-color: #f1f1f1;
                                    }

                                    /* Style the buttons that are used to open the tab content */
                                    .tab button {
                                    background-color: inherit;
                                    float: left;
                                    border: none;
                                    outline: none;
                                    cursor: pointer;
                                    padding: 14px 16px;
                                    transition: 0.3s;
                                    }

                                    /* Change background color of buttons on hover */
                                    .tab button:hover {
                                    background-color: #ddd;
                                    }

                                    /* Create an active/current tablink class */
                                    .tab button.active {
                                    background-color: #ccc;
                                    }

                                    /* Style the tab content */
                                    .tabcontent {
                                    display: none;
                                    padding: 6px 12px;
                                    border: 1px solid #ccc;
                                    border-top: none;
                                    }     
</style>
</head>
<body>
<?php
echo "<center>";
echo "<h1>Account Settings</h1>";




       
                if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='1'))
                   {
                        if(isset($_SESSION['Record_Label_ID']))
                           {
                            echo "<h3> <span><img src='images/User.png' width='30px' height='30px'> </span>Welcome " . $_SESSION['Record_Label_Full_Name'] . "</h3>";
                           }
                   }
                   if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='2'))
                   {
                        if(isset($_SESSION['Artist_ID']))
                           {
                            echo "<h3> <span><img src='images/User.png' width='30px' height='30px'> </span>Welcome " . $_SESSION['Artist_First_Names'] . "</h3>";
                           }
                   }

      
echo "</center>";
?>


            <div class="tab">
            <button class="tablinks" onclick="openCity(event, '1')">My Profile</button>
            <button class="tablinks" onclick="openCity(event, '3')">View Sales</button>
            <button class="tablinks" onclick="openCity(event, '2')">Submissions</button>
            <button class="tablinks">
                    
            <?php
                    echo 
                       "
                       <form method='POST' action='".userLogoutAcc($conn)."'>
                       <button class='btn btn-primary' width='30px' height='30px' name='logoutsubmit'>
                       Logout
                       </button>
                       </form>
                       ";
            ?> 
             </button>
                 
            <button class="tablinks"><a href="../index.html"><img src="images/Home.png" alt="HomeButton" width="30px" height="30px"></a></button>
            </div>


<div id="1" class="tabcontent">

<h1>Profile Details</h2><br/>

<?php
 if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='1'))
 {
      if(isset($_SESSION['Record_Label_ID']))
         {
            //  echo "<h3> <span><img src='../User.png' width='30px' height='30px'> </span>Welcome " . $_SESSION['Record_Label_Full_Name'] . "</h3>";
            echo "
            <form class='form' action='".update_profile_details($conn)."' method='POST'>
            <div class='row'>
                <div class='col-md-4'>
                      
                    <form name='signupform'>
                        <p>Record Label Name</p>
                        <input type='text'  class='form-control' placeholder='label Name' required autocomplete='off' value='".$_SESSION['Record_Label_Name']."' name='Record_Label_Name'/><br>
                        <p>Record Label Country</p>
                        <input type='text'  class='form-control' placeholder='Country' value='".$_SESSION['Record_Label_Country']."' required autocomplete='off' name='Record_Label_Country'/><br>
                        <p>Record Label Full Name(s)</p>
                        <input type='text'  class='form-control' placeholder='Full Name(s)' value='".$_SESSION['Record_Label_Full_Name']."' required autocomplete='off' name='Record_Label_Full_Name'/><br>
                        <p>Record Label Email Address</p>
                        <input type='Email'  class='form-control' placeholder='Email' value='".$_SESSION['Record_Label_Email']."' required autocomplete='off' name='Record_Label_Email'/><br>
                        <p>Record Label Phone Number</p>
                        <input type='text'  class='form-control' placeholder='Phone' value='".$_SESSION['Record_Label_Phone']."' required autocomplete='off' name='Record_Label_Phone'/><br>
                        <p>Record Label Physical Address</p>
                        <input type='text'  class='form-control' placeholder='Physical Address' value='".$_SESSION['Record_Physical_Address']."' required autocomplete='off' name='Record_Physical_Address'/><br>

                            <br/>

                </div>

                <div class='col-md-4'>
                                <br/>
                                <br/>

                            <p>Username</p>
                             <input type='text'  class='form-control' placeholder='Username' value='".$_SESSION['un']."' required autocomplete='off' name='un'/><br>

                              <p>Password</p>
                              <input type='text'  class='form-control' placeholder='Password' value='".$_SESSION['pwd']."' required autocomplete='off' name='pwd'/><br>


                              <br>
                              <button class='btn btn-primary' name='ACCOUNT_UPDATE_BUTTON'>Update Details</button>
                  
                </div>
            </div>
    </form>
            ";
         }
 }


 if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='2'))
 {
      if(isset($_SESSION['Artist_ID']))
        {
          echo 
          "
          <form class='form' action='".update_profile_details($conn)."' method='POST'>                  
          <div class='row'>
      
            <div class='col-md-4'>
      
    
                     <p>Artist Email Address</p>
                     <input type='text'  class='form-control' placeholder='Artist Email' value='".$_SESSION['Artist_Email_Address']."' required autocomplete='off' name='Artist_Email_Address'/><br>
                     <p>Artist First Name(s)</p>
                     <input type='text'  class='form-control' placeholder='Artist First Name(s)' value='".$_SESSION['Artist_First_Names']."' required autocomplete='off' name='Artist_First_Names'/><br>
                     <p>Artist Phone Number</p>
                     <input type='text'  class='form-control' placeholder='Artist Phone Number' value='".$_SESSION['Artist_Phone_Number']."' required autocomplete='off' name='Artist_Phone_Number'/><br>
                      
                     
                     <p>Record Label Name</p>
                     <input type='text' class='form-control' placeholder='Record Label Name' value='".$_SESSION['Record_Label_Name']."' required autocomplete='off' name='Record_Label_Name'/><br>
                      
                     
                   
      
      
    
       
      
         </div>
      
                     <div class='col-md-4'>
                                 <br/>
                                 <br/>
                                 <br/>
                               <p>Username</p>
                               <input type='text'  class='form-control' placeholder='Username' value='".$_SESSION['un']."' required autocomplete='off' name='un'/><br>
      
                               <p>Password</p>
                               <input type='text'  class='form-control' placeholder='Password' value='".$_SESSION['pwd']."' required autocomplete='off' name='pwd'/><br>
      
      
                               <br>
                               <button class='btn btn-primary' name='ACCOUNT_UPDATE_BUTTON'>Update Details</button>
                    
                   </div>
      
            </div> 

      </form>
      ";


         }
 }

?>
               

</div>


<div id="3" class="tabcontent">
<h1>View Sales</h2><br/>

<?php
if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='1'))  //REC
{
      // $myID = $_POST['ID'];
       $myID                          =$_SESSION['Record_Label_ID']; 

          $sql_select = "select SpreadSheetLink from record_labels WHERE Record_Label_ID='$myID'";
             
               if($result=$conn->query($sql_select))
                     {    
                       while($row = $result->fetch_assoc())
                        {
                        $hold_link= $row['SpreadSheetLink'];
                         ECHO "<iframe src='".$hold_link."'
                         width='100%'' height='2000px'>
                          </iframe>
                       ";
                        }
                      
                     }
               else
                     {
                     $message='Account Key doesnt exist or no spreadsheet is linked';
                     echo "<script type='text/javascript'> alert('$message');</script>";   
                     }
}
?>
</div>


<div id="2" class="tabcontent">
<h1>Submission Details</h2><br/>
</div>

</body>
</html>
<script>
function openCity(evt, cityName) 
{
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += "active";
}
</script>





<?php


function update_profile_details($conn)
{


  // START REC
      if(isset($_POST['ACCOUNT_UPDATE_BUTTON']))
      {
                      if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='1'))  //REC
                      {
                        $pkk                          =$_SESSION['Record_Label_ID']; 
                        $Record_Label_Name            =$_SESSION['Record_Label_Name'];
                        $Record_Label_Country         =$_SESSION['Record_Label_Country'];  
                        $Record_Label_Full_Name       =$_SESSION['Record_Label_Full_Name'];  
                        $Record_Label_Email           =$_SESSION['Record_Label_Email'];  
                        $Record_Label_Phone           =$_SESSION['Record_Label_Phone'];  

                        $Record_Physical_Address      =$_SESSION['Record_Physical_Address']; 
                        $un                           =$_SESSION['un'];
                        $pwd                          =$_SESSION['pwd'];  

                             

                        $SQL_UPDATE1 =  "UPDATE record_labels 
                                         SET 
                                                Record_Label_Name='Record_Label_Name',
                                                Record_Label_Country='Record_Label_Country',
                                                Record_Label_Full_Name='Record_Label_Full_Name',
                                                Record_Label_Email='Record_Label_Email',
                                                Record_Label_Phone='Record_Label_Phone',
                                                Record_Physical_Address='Record_Physical_Address',
                                                un='un',
                                                pwd='pwd'
                                        WHERE   Record_Label_ID='$pkk'";

                                  if($result = $conn->query($SQL_UPDATE1))
                                            {
                                              $message = "Successfully Updated";
                                              echo "<script type='text/javascript'> alert('$message');</script>"; 
                                            }
                                        else
                                            {
                                              $message = "Failed to Update";
                                              echo "<script type='text/javascript'> alert('$message');</script>"; 

                                              
                                              echo "" .  $pk   . "<br/>"; 
                                              echo "" .  $Record_Label_Name   . "<br/>";
                                              echo "" .  $Record_Label_Country  . "<br/>";  
                                              echo "" .  $Record_Label_Full_Name  . "<br/>";  
                                              echo "" .  $Record_Label_Email    . "<br/>";  
                                              echo "" .  $Record_Label_Phone    . "<br/>";  
                       
                                              echo "" .  $Record_Physical_Address   . "<br/>"; 
                                              echo "" .  $un      . "<br/>";
                                              echo "" .  $pwd     . "<br/>";  
                       



                                            }
                      
                      }

   //END REC



   //START ARTIST



            if((isset($_SESSION['UserType'])) and ($_SESSION['UserType']=='2'))  // ART
                  {

                    $Artist_Email_Address = $_POST['Artist_Email_Address'];
                    $Artist_First_Names = $_POST['Artist_First_Names'];
                    $Artist_Phone_Number = $_POST['Artist_Phone_Number'];
                    $Record_Label_Name = $_POST['Record_Label_Name'];  
                    $un = $_POST['un'];
                    $pwd = $_POST['pwd'];   
                   
                   
          $pk=$_SESSION['Artist_ID'];
          $SQL_UPDATE =  "UPDATE artists 
                          SET   
                                Artist_Email_Address='$Artist_Email_Address',
                                Artist_First_Names='$Artist_First_Names',
                                Artist_Phone_Number='$Artist_Phone_Number',
                                Record_Label_Name='$Record_Label_Name',
                                un='$un',
                                pwd='$pwd'
                         WHERE Artist_ID='$pk'";

                              if($result = $conn->query($SQL_UPDATE))
                                        {
                                          $message = "Successfully Updated,Logout and login again to view changes";
                                          echo "<script type='text/javascript'> alert('$message');</script>"; 
                                          window.location.reload();
                                        }
                              else
                                        {
                                          $message = "Failed to Update";
                                          echo "<script type='text/javascript'> alert('$message');</script>"; 
                                          window.location.reload();
                                        }

                  }  


    //END ARTIST


      }
}


function userLogoutAcc($conn)
  {

     if(isset($_POST['logoutsubmit']))
      {
             echo "<script>window.location.href='AccountLogin.php';</script>";
             exit;
          //session_destroy();
         // header("Location:AccountLogin.php");
          //ob_end_flush(); 
          //exit();

      }   
  } 

?>



