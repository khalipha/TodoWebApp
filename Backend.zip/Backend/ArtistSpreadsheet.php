<?php
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Artist SpreadSheet</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-grid.min.css"/>

   <script src="bootstrap/js/bootstrap.min.js"></script>
   <script src="jquery.js"></script>



                        <style>                           
                                    /* Style the tab */
                                    .tab {
                                    overflow: hidden;
                                    border: 1px solid #ccc;
                                    background-color: #f1f1f1;
                                    }

                                    /* Style the buttons that are used to open the tab content */
                                    .tab button {
                                    background-color: inherit;
                                    float: left;
                                    border: none;
                                    outline: none;
                                    cursor: pointer;
                                    padding: 14px 16px;
                                    transition: 0.3s;
                                    }

                                    /* Change background color of buttons on hover */
                                    .tab button:hover {
                                    background-color: #ddd;
                                    }

                                    /* Create an active/current tablink class */
                                    .tab button.active {
                                    background-color: #ccc;
                                    }

                                    /* Style the tab content */
                                    .tabcontent {
                                    display: none;
                                    padding: 6px 12px;
                                    border: 1px solid #ccc;
                                    border-top: none;
                                    }      
                                    body 
{
  font-family: "Lato", sans-serif;
}

.sidenav 
{
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a 
{
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover 
{
  color: #f1f1f1;
}

.sidenav .closebtn 
{
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) 
{
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}                            
                        </style>
</head>
<body>



<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="Forms.html">Release Track/Album</a>
  <a href="Approve_Release.php">Approve Release</a>
  <a href="Approve_Account.php">Approve Account</a>
  <a href="Sales.php">Update Sales</a> 
  <a href="PostBlog.php">Post Blog</a>
  <a href="ArtistSpreadsheet.php">Artist SpreadSheet</a>
  <a href="../index.html">Logout</a>
</div>

<h2>Andministrator Panel</h2>
<p>QPhonic Entertainment</p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
           <div class="tab">
      <button class="tablinks"><a href="../index.html"><img src="images/Home.png" alt="HomeButton" width="30px" height="30px"></a></button>
      <button class="tablinks" onclick="openCity(event, '2')">View All Sales</button>
      <button class="tablinks" onclick="openCity(event, '3')">Assign Spreadsheet Link</button>
      <button class="tablinks" onclick="openCity(event, '4')">View Account Spreadsheets</button>

            </div>



              <div id="2" class="tabcontent">
              <h3>View Sale</h3>


          <!--START  IFRAME -->

          <iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQW3kpdDG6j6II2YuhXy3Jwx9KlPxKbvtpPEcCymBCz2fXBRx-4Ov8q2SIDB64wNTumuCk8CklR2xzU/pubhtml?gid=0&amp;single=true&amp;widget=true&amp;headers=false"
            width="100%" height="2000px">
          </iframe>

          <!-- END IFRAME -->

    </div>


    <div id="3" class="tabcontent">
        <h3>Assign Spreadsheet Link to Artist Account</h3>

          <?php    

    echo "  <form action='".Assign($conn)."' method='POST'>
              <p>Enter Account ID: </p>
              <input type='text' name='ID' placeholder='Enter Account ID'/><br/>
              <p>Enter Spreadsheet Link: </p>
              <input type='text' name='Link' placeholder='Enter Spreadsheet Link'/><br/>
              <button name='Submit_Spreadsheet_Data'>Assign</button>
            </form>
    
        ";


        function Assign($conn)
              {
                if(isset($_POST['Submit_Spreadsheet_Data']))
                  {
              $myID   = $_POST['ID'];
              $myLink = $_POST['Link'];

              $sql_insert = "UPDATE artists SET SpreadSheetLink='$myLink' WHERE Artist_ID='$myID'";
              
                if($result=$conn->query($sql_insert))
                      {    
                      $message='Success';    
                      echo "<script type='text/javascript'> alert('$message');</script>";     
                      }
                else
                      {
                      $message='Failed';
                      echo "<script type='text/javascript'> alert('$message');</script>";   
                      }
                  }
              }
          ?>

    </div>

    <div id="4" class="tabcontent">
        <h3>View Account Spreadsheets</h3>

        <?php    

echo "  <form action='".View($conn)."' method='POST'>
          <p>Enter Account ID: </p>
          <input type='text' name='ID' placeholder='Enter Account ID'/><br/>  
          <button name='Submit_View'>View</button>
        </form>

    ";


    function View($conn)
          {
            if(isset($_POST['Submit_View']))
              {
          $myID = $_POST['ID'];

          $sql_select = "select SpreadSheetLink from artists WHERE Artist_ID='$myID'";
          
            if($result=$conn->query($sql_select))
                  {    
                    while($row = $result->fetch_assoc())
                     {
                     $hold_link= $row['SpreadSheetLink'];
                      ECHO "<iframe src='".$hold_link."'
                      width='100%'' height='2000px'>
                       </iframe>
                    ";
                     }
                   
                  }
            else
                  {
                  $message='Account Key doesnt exist or no spreadsheet is linked';
                  echo "<script type='text/javascript'> alert('$message');</script>";   
                  }
              }
          }
      ?>


    </div>

       
</body>
</html>


<script>
function openCity(evt, cityName) 
{
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += "active";
}
</script>