<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Post Blog</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-grid.min.css"/>

   <script src="bootstrap/js/bootstrap.min.js"></script>
   <script src="jquery.js"></script>
</head>
<style>
body 
{
  font-family: "Lato", sans-serif;
}

.sidenav 
{
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a 
{
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover 
{
  color: #f1f1f1;
}

.sidenav .closebtn 
{
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) 
{
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="Approve_Release.php">Approve Release</a>
  <a href="Approve_Account.php">Approve Account</a>
  <a href="Sales.php">Update Sales</a> 
  <a href="PostBlog.php">Post Blog</a>
  <a href="../Frontend/index.html">Logout</a>
</div>

<h2>Andministrator Panel</h2>
<p>QPhonic Entertainment</p>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
    <!-- echo 
"  
  <center><h1>Blog Post</h1><br/>

<form enctype='multipart/form-data' action='".update_blog()."' method='post' >


<h4> Title  </h4>
<input type='text' name='Title_name' id='Title_id' />        
<h4> Message  </h4>
<textarea type='textarea' name='Message_name' id='Message_id' style='height:200px'></textarea>
<h4> External Link eg: SoundCloud </h4>
<input type='text' name='Link_name' id='Link_id' />       
<br/>

Select image to upload:
<input type='file' name='file_image' id='file_image'><br/>


Select song to upload:
<input type='file' name='file_song' size='80' id='file_song'><br/>

<button name='SubmitAudio'>Blog</button>


</form> </center>"; -->

<?php

include 'db.php';

echo 
"  
  <center><h1>Blog Post</h1><br/>

<form enctype='multipart/form-data' action='".post_blog_version1($conn)."' method='post' >


<h4> Title  </h4>
<input type='text' name='Title_name' id='Title_id' />    <br/>    
<h4> Message  </h4><br/>
<textarea type='textarea' name='Message_name' id='Message_id' style='height:200px'></textarea>
<br/>

<button name='SubmitAudio'>Blog</button>


</form> </center>";



function upload_blog()
{
if(isset($_POST['SubmitAudio']))
  { 

    $blog_title = $_POST['Title_name'];
    $blog_message = $_POST['Message_name'];
    
    $TestTextFile="1.txt";
    $MyFolder = "xxxx";mkdir ($MyFolder, 0755); 
  

    $TestMyFolder1 = fopen($TestTextFile, "w") or die("Unable to open file!");
    $txt = $blog_title . ",";
    fwrite($TestMyFolder1, $txt);
    $txt = $blog_message . "\n";
    fwrite($TestMyFolder1, $txt);
    fclose($TestMyFolder1);


$status_song="";
$status_image="";


    ///START SONG
    $target_dir = $MyFolder;
    $target_file = $target_dir . basename($_FILES["file_song"]["name"]);
    
    if(move_uploaded_file($_FILES["file_song"]["tmp_name"], $target_file))
       {
        $status_song="1"; 
       }
    else
      {
        $status_song="0"; 
      }
    ///End song
        
    ///START IMAGE
    $target_dir = $MyFolder;
    $target_file = $target_dir . basename($_FILES["file_image"]["name"]);
    
    if(move_uploaded_file($_FILES["file_image"]["tmp_name"], $target_file))
       {
        $status_image="1";
       }
       else
         {
            $status_image="0";
         }
    ///END IMAGE


      if($status_image="1" and $status_song="1")
         {
      echo "Success.Image and song uploaded";
         }
     else
       {
             
                if($status_song="0")
                {
                echo "Failed.Song upload failed";
                }
                if($status_image="0") 
                  {
                    echo "Failed.Image upload failed";
                  }    
       }

       
  }
}

function post_blog_version1($conn)
{
  if(isset($_POST['SubmitAudio']))
     {
      $Blog_Title=$_POST['Title_name'];
      $Blog_Message=$_POST['Message_name'];
      $Blog_Image_Url="Temp";
      $Blog_Audio_Url="Temp";
      $Blog_Date = date("Y/m/d");
    
      $insertblog ="insert into blog(Blog_Title,Blog_Message,Blog_Image_Url,Blog_Audio_Url,Blog_Date)values('$Blog_Title','$Blog_Message','$Blog_Image_Url','$Blog_Audio_Url','$Blog_Date')";
      
      if($result=$conn->query($insertblog))
        {
    echo "Passed";
        }
        else
        {
    echo "Failed";
        }
     }
}
 
?>
</body>
</html>

