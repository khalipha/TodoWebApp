<?php
  return $conn = mysqli_connect("localhost","root","","qphonicent");

    if(!$conn)
    {
    die("Connection failed:" .mysqli_connect_error());
    }
  ?>
