<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="main.css"/>
</head>
<body>


<!--
   <form action="upload_image.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form> 
 -->


<!--
   <form action="upload_song.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form>  
-->

  

</body>
</html>




<!-- Tab links -->
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')">Login</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Register</button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')">Tokyo</button>
</div>

<!-- Tab content -->
<div id="London" class="tabcontent">
  <h3>London</h3>
  <p>London is the capital city of England.</p>
</div>

<div id="Paris" class="tabcontent">
  <h3>Paris</h3>
  <p>Paris is the capital of France.</p> 
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>

<br/>
<form method="post" action="createxml.php">
<button type="button" name="Create_XML">Click Me!</button>
</form>

<script src="jquery.js" type="text/javascript"></script>
<script src="main.js" type="text/javascript"></script>