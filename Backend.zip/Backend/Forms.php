<html>
<head>
<title></title>
   <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.min.css"/>
   <link rel="stylesheet" href="bootstrap/css/bootstrap-grid.min.css"/>
   <script src="jquery.js"></script>
   <script src="bootstrap/js/bootstrap.min.js"></script>

<style>
	 /* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons that are used to open the tab content */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px; 
  transition: 0.3s;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
	 </style>
</head>
<body>

	  <!-- Tab links -->
<div class="tab">
  <button class="tablinks" onclick="openCity(event, '1')">Step 1 - Release Info</button>
  <button class="tablinks" onclick="openCity(event, '2')">Step 2 - Upload Files</button>
  <button class="tablinks" onclick="openCity(event, '3')">Step 3 - Fill Information</button>
  <button class="tablinks" onclick="openCity(event, '4')">Step 4 - Partners</button>
</div>


<div id="1" class="tabcontent">
  <h3>Release Info</h3>
     
  
<?php
echo 
"<form class='form' method='POST' action='".Hold_Step1()."'>
	      
		   
<!-- START 3  -->
<div class='form-group' >
 <div class='form-row'>
     <div class='col'>  			
     <label for='exampleInputEmail1'>Catalog Number</label>
     <input type='text' class='form-control' name='catalog_number' aria-describedby='emailHelp' placeholder='Eg: Ex. 0001'/>       							
     </div>
     
     <div class='col'>			
     <label for='exampleInputEmail1'>Format</label>
     <input type='text' class='form-control' name='format' aria-describedby='emailHelp' placeholder='Enter Format'/>								
     </div>
     
     <div class='col'>			
     <label for='exampleInputEmail1'>UPC</label>
     <input type='text' class='form-control' name='upc' aria-describedby='emailHelp' placeholder='Enter UPC'/>       				
     </div>
     
     
   </div>
  </div>
<!-- END 3 -->


     <label for='exampleInputEmail1'>Release Title</label>
     <div class='col-md-6'>
     <input type='text' class='form-control' name='release_title' aria-describedby='emailHelp' placeholder='Enter Release Title'/>
     <small id='emailHelp' class='form-text text-muted'>We'll never share your email with anyone else.</small>
     </div>
     
     <label for='exampleInputEmail1'>Release Artist</label>
     <div class='col-md-6'>
     <input type='text' class='form-control' name='release_artist' aria-describedby='emailHelp' placeholder='Enter Release Artist'/>               
     </div>
     
     <label for='exampleInputEmail1'>Credit / Full Description</label>
     <div class='col-md-6'>
     <input type='text' class='form-control' name='credit' aria-describedby='emailHelp' placeholder='Enter Credit / Full Description'/>             
     </div>
     
     <label for='exampleInputEmail1'>Date</label>
     <div class='col-md-6'>
     <input type='text' class='form-control' name='release_date' aria-describedby='emailHelp' placeholder='Enter Date(dd/mm/yyyy)'/>            
      <small id='emailHelp' class='form-text text-muted'>Please submit 15 days before the release date above.</small>
     </div>
     
     <button class='btn btn-primary' name='ReleaseData1'>Next</button>
     
</form>
";
?>
</div>


<?php
include 'db.php';
session_start();

   function Hold_Step1()
     {
           if(isset($_POST['ReleaseData1']))
             {
                $var_Release_Catalog    =$_POST['catalog_number'];
                $var_Release_Format     =$_POST['format'];
                $var_Release_UPC        =$_POST['upc'];
                $var_Release_Title      =$_POST['release_title'];
                $var_Release_Artist     =$_POST['release_artist'];
                $var_Release_desc       =$_POST['credit'];
                $var_Release_date       =$_POST['release_date'];


                $_SESSION['var_Release_Catalog'] = $var_Release_Catalog;
                $_SESSION['var_Release_Format']  = $var_Release_Format;
                $_SESSION['var_Release_UPC']     = $var_Release_UPC;

                $_SESSION['var_Release_Title']   = $var_Release_Title;
                $_SESSION['var_Release_Artist']  = $var_Release_Artist;
                $_SESSION['var_Release_desc']    = $var_Release_desc;

                $_SESSION['var_Release_date']    = $var_Release_date;

                echo

                "" . $_SESSION['var_Release_Catalog'].    "".
                "" . $_SESSION['var_Release_Format'].     "".
                "" . $_SESSION['var_Release_UPC'].        "".
                "" . $_SESSION['var_Release_Title'].      "".
                "" . $_SESSION['var_Release_Artist'].     "".
                "" . $_SESSION['var_Release_desc'].       "".
                "" . $_SESSION['var_Release_date'].       ""
                ;
             }
        
     }
     function Hold_Step2()
     {
       if(isset($_POST['']))
          {

          }
     }
?>



<div id="2" class="tabcontent">
<?php

echo
"
<h3>Upload Files</h3>
  

               <form method='POST' action='upload_song.php'>
               <label for='AudioUpload'>Upload Track / Album</label>
               <input type='file' class='form-control-file' id='AudioUpload'> </br>
               <button type='button' class='btn btn-primary' name='AddSong'>Add Song</button>
               </form>
                
            <br/><button type='button' class='btn btn-primary' name='AddSong_AddImage'>Next</button>  
";


function Add_Audio()
{
    if (isset($_POST['AddSong']))
    {
        echo "Hello";
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);      
        move_uploaded_file($_FILES["AudioUpload"]["tmp_name"], $target_file);
    }
}

?>
</div>





<div id="3" class="tabcontent">

<?php

echo 
"
<form method='POST' action='".Hold_Fill_Information()."'>

    <h3>Fill Information</h3>
   

   <label for='exampleInputEmail1'>Artist Name</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='ArtistName' placeholder='Enter Artist Name'/>            
   </div>
   
   <label for='exampleInputEmail1'>Title</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='Title' a placeholder='Enter Title'/>            
   </div>
   
   
   <label for='exampleInputEmail1'>Versionie</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='Versionie' placeholder='Enter Versionie'/>            
   </div>
   
   <label for='exampleInputEmail1'>Add Remixer</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='Remixer'  placeholder='Enter Remixer'/>            
   </div>
   
   
      <div class='col-md-6'>
       <label for='exampleFormControlSelect1'>Genre</label>
       <select class='form-control' name='Genre'>
         <option>Afro</option>
         <option>House</option>
         <option>Deep House</option>
         <option>Soulful House</option>
         <option>Nu Disco/Indie Dance</option>
         <option>Jackin House</option>
         <option>Classic House</option>
         <option>Tech House</option>
         <option>Techno</option>
         <option>Classic House</option>
         <option>Chillout/Lounge</option>
         <option>Broken Beat/Nu Jazz</option>
         <option>Afro/Latin/Brazilian</option>
         <option>Progressive House</option>
         <option>Electro House</option>
         <option>Electronica</option>
         <option>Minimal</option>
         <option>Leftfield</option>
         <option>Hip-Hop</option>
       </select>
     </div>
   
   <label for='exampleInputEmail1'>Copyright</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='Copyright' aria-describedby='emailHelp' placeholder='Enter Copyright'/>            
   </div>
   
   <label for='exampleInputEmail1'>ISRC Code</label>
   <div class='col-md-6'>
   <input type='text' class='form-control' name='Isrc_Code' aria-describedby='emailHelp' placeholder='Enter ISRC Code'/>            
   </div>

   <button name='Step3Submit' class='btn btn-primary'>Next</button>

</form>

";

function Hold_Fill_Information()   //Step 3
{
  if(isset($_POST['Step3Submit']))
  {
   $_SESSION['ArtistName']=$_POST['ArtistName'];
   $_SESSION['Title']=$_POST['Title'];
   $_SESSION['Versionie']=$_POST['Versionie'];
   $_SESSION['Remixer']=$_POST['Remixer'];
   $_SESSION['Genre']=$_POST['Genre'];
   $_SESSION['Copyright']=$_POST['Copyright'];
   $_SESSION['Isrc_Code']=$_POST['Isrc_Code'];

echo

          "" . $_SESSION['ArtistName']. "".
          "" . $_SESSION['Title']. "".
          "" . $_SESSION['Versionie']. "".
          "" . $_SESSION['Remixer']. "".
          "" . $_SESSION['Genre']. "".
          "" . $_SESSION['Copyright']. "".
          "" . $_SESSION['Isrc_Code']. "";

  }
}


?>
   
</div>





<div id="4" class="tabcontent">

<?php
echo 
     "

    <form method='POST' action='".Step4Data()."' >
     <h3>Partners</h3>
    
         
		 
     <span></span> <span> </span><span></span>
     
     <input type='checkbox' class='' name='Itunes[]'/>
     <label class='' for='exampleCheck1'>Itunes</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Spotify[]'/>
     <label class='' for='exampleCheck1'>Spotify</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Deezer[]'/>
     <label class='' for='exampleCheck1'>Deezer</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Pandora[]'/>
     <label class='' for='exampleCheck1'>Pandora</label>
     
      <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Alibaba[]'/>
     <label class='' for='exampleCheck1'>Alibaba</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='NetEase[]'/>
     <label class='' for='exampleCheck1'>NetEase</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Amazon[]'/>
     <label class='' for='exampleCheck1'>Amazon</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Dubset[]'/>
     <label class='' for='exampleCheck1'>Dubset</label>
     
     <span></span <span>,</span<span></span>
     
     <input type='checkbox' class='' name='Tencent[]'/>
     <label class='' for='exampleCheck1'>Tencent</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Saavn[]'/>
     <label class='' for='exampleCheck1'>Saavn</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Tnameal[]'/>
     <label class='' for='exampleCheck1'>Tnameal</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='GooglePlay[]'/>
     <label class='' for='exampleCheck1'>Google Play</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='IHeartRadio[]'/>
     <label class='' for='exampleCheck1'>IHeartRadio</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='MelonPlus[]'/>
     <label class='' for='exampleCheck1'>MelonPlus</label>
     
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Shazam[]'/>
     <label class='' for='exampleCheck1'>Shazam</label>
     
     
     <span></span <span>,</span<span></span>
     
     <input type='checkbox' class='' name='YandexRU[]'/>
     <label class='' for='exampleCheck1'>Yandex RU</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='SoundExchange[]'/>
     <label class='' for='exampleCheck1'>SoundExchange</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Brasbeat[]'/>
     <label class='' for='exampleCheck1'>Brasbeat</label>
     
      <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='Traxsource[]'/>
     <label class='' for='exampleCheck1'>Traxsource</label>
     
     <span></span> <span>,  </span><span></span>
     
     <input type='checkbox' class='' name='JunoDownload[]'/>
     <label class='' for='exampleCheck1'>JunoDownload</label>
     
     
     
     
     <br/><br/><div class='form-check'>
     <input type='checkbox' class='' name='SelectAll[]'/>
     <label class='' for='exampleCheck1'>Select All</label>
     </div>
          
     <br/><button type='button' class='btn btn-primary' name='SubmitPartners'>Submit</button>
     
     </form>
     
    ";


      function Step4Data()
      {
        if(isset($_POST['SubmitPartners']))
        {
          
        }
      }

    ?>
</div>
	  
	  
	  
	  
</body>
</html>
<script>
function openCity(evt, cityName) 
{
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>








