<?php

include 'db.php';

        if(isset($_SESSION['U_ID']))
         {

          echo "
             <form action='".userLogout($conn)."' method='POST' id='logof'>
            <p class='text-center'><button type='submit' class='form-control' name='logoutsubmit'>Logout
             </button></p>
             </form>

          ";
          }
       else
          {
           echo "
             <form action='".getLogin($conn)."' method='POST' onsubmit='return validateForm()'>
             <input type='text' name='username' class='form-control' placeholder='Username'><br/><br/>
             <input type='password' class='form-control' name='password' placeholder='Password'><br/><br/>
             <p class='text-center'><button type='submit'class='form-control logb' name='loginsubmit'>Login</button></p>
             </form>
             ";
            }

function getLogin($conn)
  {   
    if(isset($_POST['loginsubmit']))
    {
      //' or '1'='1' injection
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);

    $sql = "select * from user where Username='$username' and Password='$password'";

    $result = $conn->query($sql);

    
    if(mysqli_num_rows($result) > 0) //exists
        {
             if($row = $result->fetch_assoc())
                 {
                  $_SESSION['U_ID'] = $row['U_ID'];
                  $_SESSION['Name'] = $row['Name'];
                  // header("location: login.php");
                  header("location: MasterPage.php");
                  exit();
                 }
        }
    else //invalid user data
      {          
            echo "Invalid username or password<br>";
            echo "<a href='login.php'>Try again</a>";      
            // header("location: index.php");        
            ob_end_flush();
            exit();
      }
     } // end loginsubmit
  }   //end function

function userLogout()
  {
     if(isset($_POST['logoutsubmit']))
      {
          session_start();
          session_destroy();
          header("location: login.php");
          ob_end_flush(); 
          exit();
      }   //end logoutsubmit
  } //end function
?>