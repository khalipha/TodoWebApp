<?php

$target_path = "uploads/";

$target_path = $target_path . basename( $_FILES['AudioUpload']['name']);

//Get the uploaded file information

$name_of_uploaded_file =basename($_FILES['AudioUpload']['name']);

//get the size of the file

$size_of_uploaded_file = $_FILES["AudioUpload"]["size"]/1024;//size in KBs

//get the file extension of the file

$type_of_uploaded_file = substr($name_of_uploaded_file, strrpos($name_of_uploaded_file, '.') + 1);

//echo $size_of_uploaded_file;

$max_allowed_file_size = 20000; // size in KB

//Validations

if($size_of_uploaded_file>$max_allowed_file_size )
{

  $errors .= "\n Size of file should be less than $max_allowed_file_size";

  echo $errors;

  exit();

}

$allowed_extensions = array("mp3");

//------ Validate the file extension -----

$allowed_ext = false;

for($i=0; $i < sizeof($allowed_extensions); $i++)
{

  if(strcasecmp($allowed_extensions[$i],$type_of_uploaded_file) == 0)
  {

    $allowed_ext = true;

  }

}

if(!$allowed_ext)
{

  $errors ="The uploaded file is not supported file type";

  echo 'not a song. Error = '.$errors;

  exit();

}
   //$t_remaining = $time_remaining-$duration_of_song ;

  if(move_uploaded_file($_FILES['AudioUpload']['tmp_name'], 'Songs/')) 
  {

        // perform any operation 

    echo "successfully uploaded";

        chmod ("Songs/". basename( $_FILES['AudioUpload']['name']), 0777);

} 
else
{

    echo "error in uploading";

}

?>