
<?php 
$folder = date("Ymd");mkdir ($folder, 0755); 
?>
