<?php
include 'db.php';
ob_start();
?>
<?php
   session_start();
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset='utf-8' />
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Account Login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-reboot.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-grid.min.css'/>

</head>    
<body>
	<div class="container">

   </br></br></br></br></br></br></br></br>
   <center><h1>Login</h1>


        <!--start user session details-->
        <div class="row col-md-12 boxUserSession">
          <?php
           if(isset($_SESSION['Record_Signup']))
           { echo "<h3> <span><img src='../User.png' width='30px' height='30px'> </span>Welcome,</h3>";
             echo "<h3>" .$_SESSION['Record_label_Name']. "</h3>";}
         else
           { echo "<h3><center>NOT LOGGED IN</center></h3>"; }
          ?>
        </div>
        <!--end user session details-->
      <div class="row">
      <div class="col-md-4">
      <div class="boxLogDetails" id="log">

      <!-- Begin user details -->
      <?php
              if(isset($_SESSION['Record_Signup']))
              {
     
               echo "
                  <form action='".userLogoutAcc($conn)."' method='POST' id='logof'>
                 <p class='text-center'><button type='submit' class='form-control' name='logoutsubmit'>Logout
                  </button></p>
                  </form>
     
               ";
               }
            else
              {
     
                echo "
                  <form action='".getLoginAcc($conn)."' method='POST' onsubmit='return validateForm()' class='form'>
                  <input type='text' name='username' class='form-control' placeholder='Username'><br/><br/>
                  <input type='password' class='form-control' name='password' placeholder='Password'><br/><br/>
                  <select name='UserType'>
                    <option value='1'>Record Label</option>
                    <option value='2'>Artist</option>
                  </select>
                  <p class='text-center'><button type='submit'class='form-control logb' class='btn btn-primary' name='loginsubmit'>Login</button></p>
                  </form>
                  ";
                }
               // $USERTYPE='0';
function getLoginAcc($conn)
                  {   
                    if(isset($_POST['loginsubmit']))
                    {
                      //' or '1'='1' injection
                
                    $username = mysqli_real_escape_string($conn,$_POST['username']);
                    $password = mysqli_real_escape_string($conn,$_POST['password']);
                    $USERTYPE = $_POST['UserType'];


                    if ($USERTYPE=='1')
                    {  //REC
                      $sql = "select * from record_labels where un='$username' and pwd='$password'";
                    }
                    if ($USERTYPE=='2')
                    {  //ART
                      $sql = "select * from artists where un='$username' and pwd='$password'";
                    }
                    $result = $conn->query($sql);
                
                    
                    if(mysqli_num_rows($result) > 0) //exists
                        {
                             if($row = $result->fetch_assoc())
                                 {
                                  if ($USERTYPE=='1')  //REC SESSION DATA
                                      {
                                        $_SESSION['Record_Label_ID']          =$row['Record_Label_ID'];
                                        $_SESSION['Record_Label_Name']        =$row['Record_Label_Name'];
                                        $_SESSION['Record_Label_Country']     =$row['Record_Label_Country'];
                                        $_SESSION['Record_Label_Full_Name']   =$row['Record_Label_Full_Name'];
                                        $_SESSION['Record_Label_Email']       =$row['Record_Label_Email'];
                                        $_SESSION['Record_Label_Phone']       =$row['Record_Label_Phone'];
                                        $_SESSION['Record_Physical_Address']  =$row['Record_Physical_Address']; 
                                        $_SESSION['un']                       =$row['un'];
                                        $_SESSION['pwd']                      =$row['pwd'];
                                        $_SESSION['Record_Label_Key']         =$row['Record_Label_Key'];
                                        $_SESSION['Status']                   =$row['Status'];
                                        $_SESSION['Date_Created']             =$row['Date_Created'];
                                      }
                                  if ($USERTYPE=='2')  //ARTIST SESSION DATA
                                      {
                                        $_SESSION['Artist_ID']                =$row['Artist_ID'];
                                        $_SESSION['Artist_Email_Address']     =$row['Artist_Email_Address'];
                                        $_SESSION['Artist_First_Names']       =$row['Artist_First_Names'];
                                        $_SESSION['Artist_Phone_Number']      =$row['Artist_Phone_Number'];
                                        $_SESSION['Record_Label_Name']        =$row['Record_Label_Name'];
                                        $_SESSION['un']                       =$row['un'];      
                                        $_SESSION['pwd']                      =$row['pwd'];
                                        $_SESSION['Artist_Key']               =$row['Artist_Key'];
                                        $_SESSION['Status']                   =$row['Status'];
                                        $_SESSION['Date_Created']             =$row['Date_Created'];
                                      }


                                        $_SESSION['UserType'] = $USERTYPE;
                                        //$message = $_SESSION['Record_Label_ID'];
                                       // echo "<script type='text/javascript'> alert('$message');</script>";   
                                        header("location: Account_Settings.php");
                                        exit();
                
                                 }
                        }
                    else //invalid user data
                      {          
                            echo "Invalid username or password<br>";
                            echo "<a href='AccountLogin.php'>Try again</a>";
                            ob_end_flush();
                            exit();
                      }
                     } 
                  }                  
function userLogoutAcc($conn)
  {

     if(isset($_POST['logoutsubmit']))
      {
          session_start();
          session_destroy();
          header("location: ../index.html");
          ob_end_flush(); 
          exit();

      }   
  } 

?>
          
  </div>
  </div>
  </div>
  </center>
</body>
</html>
