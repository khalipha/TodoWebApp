<?php
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8' />
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Account Signup </title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-reboot.min.css'/>
    <link rel='stylesheet' href='bootstrap/css/bootstrap-grid.min.css'/>


                        <style>                           
                                    /* Style the tab */
                                    .tab {
                                    overflow: hidden;
                                    border: 1px solid #ccc;
                                    background-color: #f1f1f1;
                                    }

                                    /* Style the buttons that are used to open the tab content */
                                    .tab button {
                                    background-color: inherit;
                                    float: left;
                                    border: none;
                                    outline: none;
                                    cursor: pointer;
                                    padding: 14px 16px;
                                    transition: 0.3s;
                                    }

                                    /* Change background color of buttons on hover */
                                    .tab button:hover {
                                    background-color: #ddd;
                                    }

                                    /* Create an active/current tablink class */
                                    .tab button.active {
                                    background-color: #ccc;
                                    }

                                    /* Style the tab content */
                                    .tabcontent {
                                    display: none;
                                    padding: 6px 12px;
                                    border: 1px solid #ccc;
                                    border-top: none;
                                    }                                  
                        </style>
</head>
<body>
            <div class="tab">
            

            <button class="tablinks" onclick="openCity(event, '1')">Register Record Label</button>
            <button class="tablinks" onclick="openCity(event, '2')">Register Artist</button>
            <button class="tablinks"><a href="AccountLogin.php"><input type="submit" class="btn btn-primary" width="30px" height="30px" name="Login" value="Login"/></a></button>
            <button class="tablinks"><a href="../index.html"><img src="images/Home.png" alt="HomeButton" width="30px" height="30px"></a></button>
            </div>


            



<div id="1" class="tabcontent">
  <h3>Register Record Label</h3>


          <?php
        echo 

        "
                <form class='form' action='".fnSubmitRecordLabelData($conn)."' method='POST'>
                <div class='row'>
                    <div class='col-md-4'>
                                <b><span style='color:red'>RECORD LABEL DETAILS below:</span></b>
                                    <br/>
                                    <br/>

                          <form action='' method='post' name='signupform'>
                            <p>Record Label Name</p>
                            <input type='text'  class='form-control' placeholder='label Name' required autocomplete='off' name='Record_Label_Name'/><br>
                            <p>Record Label Country</p>
                            <input type='text'  class='form-control' placeholder='Country' required autocomplete='off' name='Record_Label_Country'/><br>
                            <p>Record Label Full Name(s)</p>
                            <input type='text'  class='form-control' placeholder='Full Name(s)' required autocomplete='off' name='Record_Label_Full_Name'/><br>
                            <p>Record Label Email Address</p>
                            <input type='Email'  class='form-control' placeholder='Email' required autocomplete='off' name='Record_Label_Email'/><br>
                            <p>Record Label Phone Number</p>
                            <input type='text'  class='form-control' placeholder='Phone' required autocomplete='off' name='Record_Label_Phone'/><br>
                            <p>Record Label Physical Address</p>
                            <input type='text'  class='form-control' placeholder='Physical Address' required autocomplete='off' name='Record_Physical_Address'/><br>

                                <br/>

                    </div>

                    <div class='col-md-4'>
                                    <br/>
                                    <br/>

                                <p>Username</p>
                        -          <input type='text'  class='form-control' placeholder='Username' required autocomplete='off' name='un'/><br>

                                  <p>Password</p>
                                  <input type='text'  class='form-control' placeholder='Password' required autocomplete='off' name='pwd'/><br>


                                  <br>
                                  <button class='btn btn-primary' name='SubmitRecordLabelData'>Submit</button>
                      
                    </div>
                </div>
        </form>
        

        ";
        
        ?>
</div>


<div id="2" class="tabcontent">
  <h3>Register Artist</h3>
  <?php

    echo 
    "
    <form class='form' action='".fnSubmitArtistData($conn)."' method='POST'>                  
    <div class='row'>

      <div class='col-md-4'>

       <b><span style='color:red'>ARTIST DETAILS:</span></b>
           <br/>
           <br/>

               <p>Artist Email Address</p>
               <input type='text'  class='form-control' placeholder='Artist Email' required autocomplete='off' name='Artist_Email_Address'/><br>
               <p>Artist First Name(s)</p>
               <input type='text'  class='form-control' placeholder='Artist First Name(s)' required autocomplete='off' name='Artist_First_Names'/><br>
               <p>Artist Phone Number</p>
               <input type='text'  class='form-control' placeholder='Artist Phone Number' required autocomplete='off' name='Artist_Phone_Number'/><br>
                
               
               <p>Record Label Name</p>
               <input type='text' class='form-control' placeholder='Record Label Name' required autocomplete='off' name='Record_Label_Name'/><br>
                
               
             


";
 

   ECHO"      </div>

               <div class='col-md-4'>
                           <br/>
                           <br/>
                           <br/>
                         <p>Username</p>
                         <input type='text'  class='form-control' placeholder='Username' required autocomplete='off' name='un'/><br>

                         <p>Password</p>
                         <input type='text'  class='form-control' placeholder='Password' required autocomplete='off' name='pwd'/><br>


                         <br>
                         <button class='btn btn-primary' name='SubmitArtistData'>Submit</button>
              
             </div>

      </div> 
</form>
    
    ";
  ?>

      
  

  
  
  

</div>
<body>

<script>
function openCity(evt, cityName) 
{
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += "active";
}
</script>




<?php

function fnSubmitArtistData($conn)
{

  if (isset($_POST['SubmitArtistData']))
  {
    $Artist_Email_Address = $_POST['Artist_Email_Address'];
    $Artist_First_Names = $_POST['Artist_First_Names'];
    $Artist_Phone_Number = $_POST['Artist_Phone_Number'];
    $Record_Label_Name = $_POST['Record_Label_Name'];  
    $un = $_POST['un'];
    $pwd = $_POST['pwd'];   
    $Artist_Key = "0";
    $Status="1";
    $date = date('Y-m-d H:i:s');
    $Spreadsheet="Not Spread Sheet provided";


    $insert_artist = "insert into artists(
    Artist_Email_Address,
    Artist_First_Names,
    Artist_Phone_Number,
    Record_Label_Name,
    un,
    pwd,
    Artist_Key,Status,Date_Created,SpreadSheetLink)
    values('$Artist_Email_Address',
           '$Artist_First_Names',
           '$Artist_Phone_Number',
           '$Record_Label_Name',
           '$un',
           '$pwd',
           '$Artist_Key',
           '$Status',
           '$date',
           '$Spreadsheet')";

           if($result=$conn->query($insert_artist))
           {    
            $message='Success';    
            echo "<script type='text/javascript'> alert('$message');</script>";     
          }
             else
          {
            $message='Failed';
            echo "<script type='text/javascript'> alert('$message');</script>";   
          }
  }
}





function fnSubmitRecordLabelData($conn)
{
  if (isset($_POST['SubmitRecordLabelData']))
  {
    $Record_Label_Name = $_POST['Record_Label_Name'];
    $Record_Label_Country = $_POST['Record_Label_Country'];
    $Record_Label_Full_Name = $_POST['Record_Label_Full_Name'];
    $Record_Label_Email = $_POST['Record_Label_Email'];
    $Record_Label_Phone = $_POST['Record_Label_Phone'];
    $Record_Physical_Address = $_POST['Record_Physical_Address'];
    $un = $_POST['un'];
    $pwd = $_POST['pwd'];
    $Record_Label_Key = "0"; 
    $Status ="1"; 
    $date = date('Y-m-d H:i:s');
    $Spreadsheet="Not Spread Sheet provided";




    $insert_recordlabel = "insert into record_labels(
                            Record_Label_Name,
                            Record_Label_Country,
                            Record_Label_Full_Name,
                            Record_Label_Email,
                            Record_Label_Phone,
                            Record_Physical_Address,
                            un,pwd,Record_Label_Key,
                            Status,Date_Created,SpreadSheetLink)
                            values('$Record_Label_Name',
                                   '$Record_Label_Country',
                                   '$Record_Label_Full_Name',
                                   '$Record_Label_Email',
                                   '$Record_Label_Phone',
                                   '$Record_Physical_Address',
                                   '$un',
                                   '$pwd',
                                   '$Record_Label_Key',
                                   '$Status',
                                   '$date','$Spreadsheet')";                

    if($result=$conn->query($insert_recordlabel))
    {    
      $message='Success';    
      echo "<script type='text/javascript'> alert('$message');</script>";     
    }
       else
    {
      $message='Failed';
      echo "<script type='text/javascript'> alert('$message');</script>";   
    }
  }
}






?>